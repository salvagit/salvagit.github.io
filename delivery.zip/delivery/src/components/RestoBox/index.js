import React from 'react';
import { Link } from "react-router-dom";

export default ({ resto }) =>
  <div className="card" style={{width: '18rem'}}>
    <div className="card-body">
      <h5 className="card-title">{resto.name}</h5>
      <p className="card-text">{resto.description}</p>
      <Link
        to={{
          pathname: '/place-order',
          resto
        }}
      >
        Enviar Pedido
      </Link>
    </div>
  </div>