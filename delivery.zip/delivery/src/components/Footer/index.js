import React from 'react';

export default () =>
  <footer className="footer bg-dark"></footer>