import React from 'react';
import RestoBox from '../RestoBox';

export default ({restaurants}) =>
  <div>
    <h2>Deliveries:</h2>
    <div className='card-columns' >
      {
        restaurants.map( element =>
          <RestoBox key={element.id} resto={element} />)
      }
    </div>
  </div>