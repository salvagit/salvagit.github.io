import React from 'react';
import { Link } from "react-router-dom";

export default ({step}) =>
  <header>
    <nav className="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a className="navbar-brand" href="#">Delivery Online</a>
      <div className="collapse navbar-collapse" id="navbarCollapse">
        <ul className="navbar-nav mr-auto"></ul>

        <div className="btn-group btn-group-toggle" data-toggle="buttons">
          <label className={`btn btn-secondary ${(1 === step) ? 'active' : ''}`}>
            <input type="radio" name="options" id="option1" autoComplete="off" />
            1 - Elegí tu delivery
          </label>
          <label className={`btn btn-secondary ${(2 === step) ? 'active' : ''}`}>
            <input type="radio" name="options" id="option2" autoComplete="off" />
            2 - Realiza tu pedido
          </label>
          <label className={`btn btn-secondary ${(3 === step) ? 'active' : ''}`}>
            <input type="radio" name="options" id="option3" autoComplete="off" />
            3 - Completa tus datos
          </label>
        </div>



      </div>
    </nav>
  </header>