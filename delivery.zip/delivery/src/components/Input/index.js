import React from 'react';
import styles from './styles'

export default ({ placeholder, label, input, meta: { touched, error, valid }, ...inputProps }) =>
  <div style={styles.inputContainer}>
    <label>{label}</label>
    <input
      type="text"
      {...inputProps}
      onChange={input.onChange}
      onBlur={input.onBlur}
      onFocus={input.onFocus}
      value={input.value}
      placeholder={placeholder ||  label}
    />
    {
      touched && (error &&
        <p style={{ color: 'red' }}>{error}</p>)
    }
  </div>