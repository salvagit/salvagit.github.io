export default {
  inputContainer: {
    display: 'inline-block'
  } 
}