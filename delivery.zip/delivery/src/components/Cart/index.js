import React from 'react';
import { connect } from 'react-redux';
import { updateCount, removeItem } from '../../actions/cart.actions';

const Cart = ({ cart, removeItem, updateCount, cartTotal }) =>
  <table className='table table-bordered'>
    <thead>
      <tr>
        <th></th>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Precio</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
      {
        cart.map((item, index) =>
          <tr key={index}>
            <td>
              <button onClick={() => removeItem(item)} >
                <img width="20" height="20" src='./images/remove.svg' />
              </button>
            </td>
            <td>{item.title}</td>
            <td>
              <input
                type='number'
                onChange={evt => updateCount(item, evt.target.value)}
                value={item.count}
                step="1"
                min="1"
              />
            </td>
            <td>{item.price}</td>
            <td>{item.total}</td>
          </tr>
        )
      }
    </tbody>
    <tfoot>
      {
        cartTotal != 0 ?
          <tr>
            <td colSpan="3"></td>
            <td>Total:</td>
            <td>{cartTotal}</td>
          </tr>
          :
          <tr>
            <td colSpan="5">No hay items en el carrito.</td>
          </tr>
      }
    </tfoot>
  </table>

const mapStateTopProps = state => ({
  cart: state.cart.cart,
  cartTotal: state.cart.cartTotal,
  state
});

const mapDispatchTopProps = dispatch => ({
  removeItem: item => dispatch(removeItem(item)),
  updateCount: (item, newCount) => dispatch(updateCount(item, newCount))
});

export default connect(mapStateTopProps, mapDispatchTopProps)(Cart);