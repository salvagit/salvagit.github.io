import React, { Component } from 'react';
import styles from './styles';

export default class Menu extends Component {

  constructor(props) {
    super(props);
    this.state = {
      menu: [],
      categories: []
    }
  }

  componentWillReceiveProps(props) {
    if (props.menu.length > 0) {
      this.getMenu(props.menu);
      this.getCategories(props.menu);
    }
  }

  getMenu(menu) {
    this.setState({ menu: menu });
  }

  getCategories(menu) {
    let categories = ['Todos'];
    menu.forEach( el => {
      if (categories.indexOf(el.category) === -1)
        categories = [ ...categories, el.category ];
    });
    this.setState({ categories });
  }

  categoryFilter(category) {
    if( 'Todos' === category ) return this.getMenu();
    this.setState(
      { menu: this.props.menu.filter( item => item.category === category ) }
    );
  }

  render () {
    return (
      <div style={styles.container}>
        <table className="table table-hover col-4">
          <tbody>
            {
              this.state.categories.map( (item, index) =>
                <tr key={ index }>
                  <td onClick={ () => this.categoryFilter(item) } className={styles.pointer}>
                    <a>
                      { item }
                    </a>
                  </td>
                </tr> )
            }
          </tbody>
        </table>
        <table className="table table-striped col-8">
          <tbody>
            {
              this.state.menu.map(
                (item, index) =>
                  <tr key={ index }>
                    <td>{ item.title }</td>
                    <td>${ item.price }</td>
                    <td>
                      <button data-toggle="tooltip" title={ item.description }>
                        <img width="20" height="20" src='./images/info.svg' />
                      </button>
                      <button onClick={ () => this.props.addToCart(item) } >
                        <img width="20" height="20" src='./images/add-to-cart.svg' />
                      </button>
                    </td>
                  </tr>
              )
            }
          </tbody>
        </table>
      </div>
    );
  }
}