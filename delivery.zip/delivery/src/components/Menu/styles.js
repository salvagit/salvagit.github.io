export default {
  container: {
    display: 'flex',
    justifyContent: 'flex-start'
  },
  pointer: {
    cursor: 'pointer'
  }
}