import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import SelectRestaurant from '../SelectRestaurant';
import PlaceOrder from '../PlaceOrder';
import Checkout from '../Checkout';

export default class App extends Component {

  render() {
    return (
      <Router>
        <div>
          <Route exact path="/" component={SelectRestaurant} />
          <Route exact path="/place-order" component={PlaceOrder} />
          <Route exact path="/checkout" component={Checkout} />
        </div>
      </Router>
    );
  }

}