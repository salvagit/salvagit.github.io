import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom'

import { addToCart } from '../../actions/cart.actions';
import { selectedResto } from '../../actions/restaurants.actions';

import Menu from '../../components/Menu';
import Cart from '../../components/Cart';
import styles from './styles';
import Layout from '../Layout';

class PlaceOrder extends Component {

  constructor(props) {
    super(props);
    this.state = {
      menu: []
    }
  }

  componentWillMount() {
    if (!this.props.location.selectedRestaurant && this.props.location.resto) {
      this.props.selectedResto(this.props.location.resto);
    }
    
    if (!this.props.location.resto) {
      <Redirect
        to={{
          pathname: "/"
        }}
      />
    }
  }

  render() {
    return (
      <Layout
        step={2}
      >
        <h2>Realiza tu pedido!</h2>
        <div className="row">

          <div className='col-6'>
            <Menu
              menu={ this.props.selectedRestaurant.menu }
              addToCart={ item => this.props.addToCart(item) }
            />
          </div>

          <div className='col-6'>
            <Cart />
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <Link className="btn btn-primary" style={styles.link} to="/">Atras</Link>
              <Link
                className="btn btn-primary" 
                style={styles.link}
                to="/checkout"
                onClick = { e => {
                  if (this.props.cart.length === 0) e.preventDefault()
                }}
              >Continuar</Link>
            </div>
          </div>

        </div>
      </Layout>
    );
  }
}

const mapStateTopProps = state => ({
  cart: state.cart.cart,
  selectedRestaurant: state.restaurants.selectedRestaurant,
  state
});

const mapDispatchTopProps = dispatch => ({
  addToCart: item => dispatch(addToCart(item)),
  selectedResto: resto => dispatch(selectedResto(resto))
});

export default connect(mapStateTopProps, mapDispatchTopProps)(PlaceOrder);