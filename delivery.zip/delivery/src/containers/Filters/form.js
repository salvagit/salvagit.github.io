import React from 'react';
import { Field, reduxForm } from 'redux-form';
import Input from '../../components/Input';

const FiltersForm = ({ styles, handleFilters, ...props }) =>
  <form style={styles.form}>

    <Field
      style={styles.input}
      name = 'name'
      label='Nombre'
      component={Input}
      onChange = { (evt, text) => handleFilters('name', text) }
    />

    <Field
      style={styles.input}
      name = 'description'
      label='Descripcion'
      component={Input}
      onChange = { (evt, text) => handleFilters('description', text) }
    />
  </form>

export default reduxForm({
  form: 'filters'
})(FiltersForm);