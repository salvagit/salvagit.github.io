export default {
  form: {
    backgroundColor: '#e2e2e2',
    padding: '15px'
  },
  input: {
    margin: '0 10px'
  }
}
