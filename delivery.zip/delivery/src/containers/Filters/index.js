import React from 'react';
import Form from './form';
import styles from './styles';

export default ({ handleFilters }) =>
  <div>
    <h2>Filtros:</h2>
    <Form
      styles = { styles }
      handleFilters = { (type, text) => handleFilters(type, text) }
    />
  </div>