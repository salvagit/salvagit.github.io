import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom'
import ContactForm from './form';
import Cart from '../../components/Cart';
import Layout from '../Layout';
import styles from './styles';
import { submit } from 'redux-form'

class Checkout extends Component {
  constructor(props){
    super(props);
    this.state = {
      shown: false
    }
  }
  componentWillReceiveProps(props) {
    if (props.submitSucceeded && !this.state.shown) {
      this.setState({shown: true});
      window.alert(JSON.stringify({
        cart: props.cart,
        cartTotal: props.cartTotal,
        form: props.form
      }))
    };
  }
  render(){
    return(
      <Layout
        step={3}
      >
        <h2>Completa tus datos!</h2>
        <div className="row">

          <div className='col-6'>
            <ContactForm />
          </div>

          <div className='col-6'>
            <Cart />
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <Link className="btn btn-primary" style={styles.link} to="/place-order">Atras</Link>

              <button
                type="button"
                style={styles.link}
                className="btn btn-primary"
                onClick={() => this.props.submit() }
              >
                Realizar Pedido
              </button>

            </div>
          </div>
    
        </div>
      </Layout>
    );
  }
}

const mapStateTopProps = state => ({
  state,
  form: state.form.contactForm && state.form.contactForm.values,
  submitSucceeded: state.form.contactForm && state.form.contactForm.submitSucceeded,
  cart: state.cart.cart,
  cartTotal: state.cart.cartTotal
});

const mapDispatchTopProps = dispatch => ({
  submit: item => dispatch(submit('contactForm'))
});

export default connect(mapStateTopProps, mapDispatchTopProps)(Checkout);