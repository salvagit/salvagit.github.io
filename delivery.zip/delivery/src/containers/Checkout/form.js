import React from 'react';
import { Field, reduxForm } from 'redux-form';
import Input from '../../components/Input';
import styles from './styles';
import validate from './validate';
import submit from './submit'

const ContactForm = ({ handleSubmit, ...props }) =>
  <form style={styles.form} onSubmit={handleSubmit}>

    <Field
      style={styles.input}
      name='userName'
      label='Nombre'
      component={Input}
    />

    <Field
      style={styles.input}
      name='lastname'
      label='Apellido'
      component={Input}
    />

    <Field
      style={styles.input}
      name='address'
      label='Direccion'
      component={Input}
    />

    <Field
      style={styles.input}
      name='phone'
      label='Telefono'
      component={Input}
      />

    <Field
      style={styles.input}
      name='email'
      label='Email'
      component={Input}
    />

  </form>

export default reduxForm({
  form: 'contactForm',
  onSubmit: submit,
  validate
})(ContactForm);