export default values => {
  const errors = {};

  if (!values.userName) errors.userName = 'ingrese su nombre';
  if (!values.lastname) errors.lastname = 'ingrese su apellido';
  if (!values.address) errors.address = 'ingrese su direccion';
  if (!values.phone) errors.phone = 'ingrese su telefono';
  if (!values.email) errors.email = 'ingrese su email';

  return errors;
}