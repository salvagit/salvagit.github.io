import { SubmissionError } from 'redux-form'

export default values => {
  return ({values});
}