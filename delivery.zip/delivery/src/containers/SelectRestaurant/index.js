import React, { Component } from 'react';
import { connect } from 'react-redux';
import { getRestaurants, filterRestaurants } from '../../actions/restaurants.actions';
import Layout from '../Layout';
import Filters from '../Filters';
import { addToCart, clearCart } from '../../actions/cart.actions';

import Restaurants from '../../components/Restaurants';

class SelectRestaurant extends Component {

  constructor(props) {
    super(props);
    this.state = {
      restaurants: []
    }
  }

  componentWillMount() {
    this.props.getRestaurants();
    this.props.clearCart();
    this.setRestaurantsState(this.props);
  }

  componentWillReceiveProps(props) {
    this.setRestaurantsState(props);
  }
  
  setRestaurantsState(props) {
    if (props.restaurants.length > 0) {
      this.setState({ restaurants: props.restaurants });
    }
  }

  handleFilters(type, text) {
    this.props.filterRestaurants(type, text);
  }

  render() {
    return (
      <Layout
        step = {1}
      >
        <Filters
          handleFilters={(type, text) => this.handleFilters(type, text)}
        />
        <Restaurants
          restaurants={this.state.restaurants}
        />
      </Layout>
    );
  }

}

const mapStateTopProps = state => ({
  restaurants: state.restaurants.restaurants
});

const mapDispatchTopProps = dispatch => ({
  getRestaurants: () => dispatch(getRestaurants()),
  filterRestaurants: (type, text) => dispatch(filterRestaurants(type, text)),
  clearCart: () => dispatch(clearCart())
});

export default connect(mapStateTopProps, mapDispatchTopProps)(SelectRestaurant);