import React from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default ({step, children}) =>
  <div>
    <Header
      step={step}
    />

    <main role="main" className="container">
      {children}
    </main>

    <Footer />

  </div>