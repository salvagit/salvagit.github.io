import { combineReducers } from 'redux';
import { reducer as form } from 'redux-form';
import restaurants from './restaurants.reducer';
import cart from './cart.reducer';

const rootReducer = combineReducers({
  form,
  restaurants,
  cart
});

export default rootReducer;