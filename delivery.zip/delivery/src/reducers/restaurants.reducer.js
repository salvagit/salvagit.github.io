import {
  GET_RESTAURANTS_START,
  GET_RESTAURANTS_SUCCESS,
  GET_RESTAURANTS_ERROR,
  FILTER_RESTAURANTS_START,
  FILTER_RESTAURANTS_SUCCESS,
  FILTER_RESTAURANTS_ERROR,
  SELECT_RESTAURANT_START,
  SELECT_RESTAURANT_SUCCESS,
  SELECT_RESTAURANT_ERROR
} from '../actions/types';

const INITIAL_STATE = {
  isLoading: false,
  success: false,
  error: null,
  restaurants: {},
  selectedRestaurant: {
    menu: []
  }
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {

    case GET_RESTAURANTS_START:
      return { ...state, isLoading: true };
    case GET_RESTAURANTS_SUCCESS:
      return { ...state, success: true, restaurants: action.data, isLoading: false };
    case GET_RESTAURANTS_ERROR:
      return { ...state, isLoading: false };

    case FILTER_RESTAURANTS_START:
      return { ...state, isLoading: true };
    case FILTER_RESTAURANTS_SUCCESS:
      return { ...state, success: true, restaurants: action.data, isLoading: false };
    case FILTER_RESTAURANTS_ERROR:
      return { ...state, isLoading: false };

    case SELECT_RESTAURANT_START:
      return { ...state, isLoading: true };
    case SELECT_RESTAURANT_SUCCESS:
      return { ...state, success: true, selectedRestaurant: action.data, isLoading: false };
    case SELECT_RESTAURANT_ERROR:
      return { ...state, isLoading: false };

    default:
      return state;
  }
}