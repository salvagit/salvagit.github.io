import {
  ADD_CART_ITEM_START,
  ADD_CART_ITEM_SUCCESS,
  ADD_CART_ITEM_ERROR,
  UPDATE_COUNT_CART_ITEM_START,
  UPDATE_COUNT_CART_ITEM_SUCCESS,
  UPDATE_COUNT_CART_ITEM_ERROR,
  REMOVE_CART_ITEM_START,
  REMOVE_CART_ITEM_SUCCESS,
  REMOVE_CART_ITEM_ERROR,
  CLEAR_CART
} from '../actions/types';

const INITIAL_STATE = {
  isLoading: false,
  success: false,
  error: null,
  cart: [],
  cartTotal: 0
};

const findInCart = (cart, item) => {
  let itemInCartIndex;

  cart.filter((i, index) => {
    if (i.id === item.id) {
      itemInCartIndex = index;
      return true;
    }
  });
  return itemInCartIndex;
}

const incrementCount = (cart, index, item, count = null) => {
  if (count) item.count = parseInt(count, 10);
  else item.count = parseInt(item.count, 10) + 1;
  item.total = parseInt(item.count, 10) * parseInt(item.price, 10);
  return [
    ...cart.slice(0, index),
    item,
    ...cart.slice(index + 1)
  ]
}

const removeItem = (cart, item) => {
  const index = findInCart(cart, item);
  item.count = 0;
  return [
    ...cart.slice(0, index),
    ...cart.slice(index + 1)
  ]
}

const getTotal = (cart) => {
  let total = 0;
  cart.forEach(el => total += el.total);
  return total;
}

export default function (state = INITIAL_STATE, action) {

  let index;
  let cart;
  let cartTotal;

  switch (action.type) {

    case ADD_CART_ITEM_START:
      return { ...state, isLoading: true };
    case ADD_CART_ITEM_SUCCESS:
      index = findInCart(state.cart, action.data);
      cart = [];
      if (undefined === index) {
        cart = [ ...state.cart, action.data ];
      } else {
        cart = incrementCount(state.cart, index, action.data );
      }
      cartTotal = getTotal(cart);
      return { ...state, success: true, cart, cartTotal, isLoading: false };
    case ADD_CART_ITEM_ERROR:
      return { ...state, isLoading: false };

    case UPDATE_COUNT_CART_ITEM_START:
      return { ...state, isLoading: true };
    case UPDATE_COUNT_CART_ITEM_SUCCESS:
      index = findInCart(state.cart, action.data);
      cart = incrementCount(state.cart, index, action.data, action.newCount);
      cartTotal = getTotal(cart);
      return { ...state, success: true, cart, cartTotal, isLoading: false };
    case UPDATE_COUNT_CART_ITEM_ERROR:
      return { ...state, isLoading: false };

    case REMOVE_CART_ITEM_START:
      return { ...state, isLoading: true };
    case REMOVE_CART_ITEM_SUCCESS:
      cart = removeItem(state.cart, action.data);
      cartTotal = getTotal(cart);
      return { ...state, success: true, cart, cartTotal, isLoading: false };
    case REMOVE_CART_ITEM_ERROR:
      return { ...state, isLoading: false };

    case CLEAR_CART:
      return { ...state, cart: [], cartTotal: 0, isLoading: false };

    default:
      return state;
  }

}