import {
  ADD_CART_ITEM_START,
  ADD_CART_ITEM_SUCCESS,
  ADD_CART_ITEM_ERROR,
  UPDATE_COUNT_CART_ITEM_START,
  UPDATE_COUNT_CART_ITEM_SUCCESS,
  UPDATE_COUNT_CART_ITEM_ERROR,
  REMOVE_CART_ITEM_START,
  REMOVE_CART_ITEM_SUCCESS,
  REMOVE_CART_ITEM_ERROR,
  CLEAR_CART
} from './types';

// Add Cart Item
export const onAddCartItemsStart = () => ({ type: ADD_CART_ITEM_START });
export const onAddCartItemsSuccess = data => ({ type: ADD_CART_ITEM_SUCCESS, data });
export const onAddCartItemsError = error => ({ type: ADD_CART_ITEM_ERROR, error });
// Update Cart Item Count
export const onUpdateCountCartItemsStart = () => ({ type: UPDATE_COUNT_CART_ITEM_START });
export const onUpdateCountCartItemsSuccess = (data, newCount) => ({ type: UPDATE_COUNT_CART_ITEM_SUCCESS, data, newCount });
export const onUpdateCountCartItemsError = error => ({ type: UPDATE_COUNT_CART_ITEM_ERROR, error });
// Remove Cart Item
export const onRemoveCartItemsStart = () => ({ type: REMOVE_CART_ITEM_START });
export const onRemoveCartItemsSuccess = data => ({ type: REMOVE_CART_ITEM_SUCCESS, data });
export const onRemoveCartItemsError = error => ({ type: REMOVE_CART_ITEM_ERROR, error });
// Clear Cart
export const onClearCart = error => ({ type: CLEAR_CART });

export function addToCart(item) {
  return dispatch => {
    dispatch(onAddCartItemsStart());
    try {
      if (!item.count) item.count = 1;
      item.total = parseInt(item.count, 10) * parseInt(item.price, 10);
      dispatch(onAddCartItemsSuccess(item));
    } catch(error) {
      dispatch(onAddCartItemsError('Ocurrió un error al intentar agregar un item al carro. ', error));
    }
  }
}

export function updateCount(item, newCount) {
  return dispatch => {
    dispatch(onUpdateCountCartItemsStart());
    try {
      dispatch(onUpdateCountCartItemsSuccess(item, newCount));
      dispatch(getCartTotal());
    } catch(error) {
      dispatch(onUpdateCountCartItemsError('Ocurrió un error al intentar actualizar la cantidad de un item al carro. ', error));
    }
  }
}

export function removeItem(item) {
  return dispatch => {
    dispatch(onRemoveCartItemsStart());
    try {
      dispatch(onRemoveCartItemsSuccess(item));
      dispatch(getCartTotal());
    } catch (error) {
      dispatch(onRemoveCartItemsError('Ocurrió un error al intentar remover un item al carro. ', error));
    }
  }
}

export function clearCart () {
  return dispatch => {
    dispatch(onClearCart());
  }
}