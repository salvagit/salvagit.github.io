import axios from 'axios';

import {
  GET_RESTAURANTS_START,
  GET_RESTAURANTS_SUCCESS,
  GET_RESTAURANTS_ERROR,
  FILTER_RESTAURANTS_START,
  FILTER_RESTAURANTS_SUCCESS,
  FILTER_RESTAURANTS_ERROR,
  SELECT_RESTAURANT_START,
  SELECT_RESTAURANT_SUCCESS,
  SELECT_RESTAURANT_ERROR
} from './types';

// Get
export const onGetRestaurantsStart = () => ({ type: GET_RESTAURANTS_START });
export const onGetRestaurantsSuccess = data => ({ type: GET_RESTAURANTS_SUCCESS, data });
export const onGetRestaurantsError = error => ({ type: GET_RESTAURANTS_ERROR, error });
// Select
export const onSelectRestaurantStart = () => ({ type: SELECT_RESTAURANT_START });
export const onSelectRestaurantSuccess = data => ({ type: SELECT_RESTAURANT_SUCCESS, data });
export const onSelectRestaurantError = error => ({ type: SELECT_RESTAURANT_ERROR, error });
// Filter
export const onFilterRestaurantsStart = () => ({ type: FILTER_RESTAURANTS_START });
export const onFilterRestaurantsSuccess = data => ({ type: FILTER_RESTAURANTS_SUCCESS, data });
export const onFilterRestaurantsError = error => ({ type: FILTER_RESTAURANTS_ERROR, error });

export function getRestaurants(id = null) {
  return dispatch => {
    dispatch( onGetRestaurantsStart() );
    axios.get('/deliveries.json')
    .then( restaurants => {
      if (id) dispatch(onGetRestaurantsSuccess(restaurants.data.filter( item => item.id == id)));
      dispatch(onGetRestaurantsSuccess( restaurants.data.sort( (a, b) => {
        if (a.name < b.name) return -1;
        if (a.name > b.name) return 1;
        return 0;
      })))
    })
    .catch( err => dispatch(onGetRestaurantsError( err )) )
  }
}

export function filterRestaurants(type, text) {
  return dispatch => {
    dispatch( onFilterRestaurantsStart() );
    axios.get('/deliveries.json')
    .then(restaurants =>
      dispatch(onFilterRestaurantsSuccess(
        restaurants.data.filter(item =>
          item[type].toLowerCase().includes(text.toLowerCase())
        )
      ))
    )
    .catch(err => dispatch(onGetRestaurantsError(err)))
  }
}

export function selectedResto (resto) {
  return dispatch => {
    dispatch(onSelectRestaurantStart());
    try {
      dispatch(onSelectRestaurantSuccess(resto));
    } catch (error) {
      dispatch(onSelectRestaurantError(resto));
    }
  }
}