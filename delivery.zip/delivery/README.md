# Salvador Palmiciano

web: https://salva.io
cv: https://salva.io/cv
mail: s@salva.io

# Conocimientos sobre Angular

Con angular trabaje en Nearpod en su web app la cual era un editor de presentaciones para una plataforma de elearning.

# Conocimientos sobre React / React Native

Desarrollo de un portal de búsqueda de empleo para un cliente de usa,
Desarrollo de un sistema de control de contenido para una marca de motos.
Desarrollo de app para búsqueda de empleo de alta rotación. (finalizando desarrollo) 
Desarrollo de app para Iphone de boton de panico para empresa de seguridad.

# Comentarios sobre el proceso y tecnología.

Me gusto implementar redux para el carrito y siento que ahora lo conozco un poquito mas.

# Install

```
$ npm install
$ npm start
```